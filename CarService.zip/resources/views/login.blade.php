@extends('layouts.app')
@section('content')
    <login-component></login-component>
@endsection