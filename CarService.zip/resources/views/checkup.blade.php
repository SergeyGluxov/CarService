@extends('layouts.app')
@section('content')
<form-checkup-component></form-checkup-component>
@endsection