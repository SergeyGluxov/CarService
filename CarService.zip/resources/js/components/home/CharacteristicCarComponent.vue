<template>
        <div class="card">
            <!-- Шапка (header) карточки -->
            <div class="card-header">
                Паспорт авто
            </div>
            <table  class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>Наименование</th>
                    <th>Эл. почта</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Гос. номер</td>
                    <td>Н703ЕТ</td>
                </tr>
                </tbody>
            </table>
        </div><!-- Конец карточки -->
</template>

<script>

</script>
<style>
    body{
        color: black;
    }
</style>