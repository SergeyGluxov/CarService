<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <script src="https://api-maps.yandex.ru/2.1/?apikey>&lang=sru_RU" type="text/javascript">
    </script>
    <script type="text/javascript" src="moment.min.js"></script>
    <script type="text/javascript" src="moment.ru.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript" defer>

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="app">
        <div class="container">
            <admin-table-component/>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>