
<?php echo $__env->make('adminlte::register', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>